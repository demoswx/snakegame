package WUXUAN;

public enum direction {
    up,down,left,right
}
